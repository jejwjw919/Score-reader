#!/usr/bin/env python3
"""PC 프로그램의 학습 데이터를 웹앱(Score Reader 모바일)용 백업 파일 하나로 묶기 (읽기만 함, 원본은 안 바뀜).

  python pc_export.py                      # C:\\arcaea 기준 기본 위치에서 읽어 score_reader_backup.json 생성
  python pc_export.py --base D:\\내폴더 -o 백업.json

묶는 것: templates\\ (숫자·난이도·등급 글자 모양, 난이도 색), 기준 글자(HIGH SCORE / MAX RECALL),
         songs.json(자켓 기억), 상수표.txt, 입력표.txt + 저장표.txt 의 점수(내 기록)
만든 파일을 폰으로 옮겨서 웹앱의 [설정 → 백업 가져오기]로 넣으면 됩니다.
"""
import argparse, base64, datetime, json, sys
from pathlib import Path

import cv2
import numpy as np

GROUPS = ["score", "hs", "level", "recall", "stat"]


def imread_gray(p):
    return cv2.imdecode(np.fromfile(str(p), dtype=np.uint8), cv2.IMREAD_GRAYSCALE)


def pack(img):
    return {"w": int(img.shape[1]), "h": int(img.shape[0]), "b64": base64.b64encode(np.ascontiguousarray(img).tobytes()).decode()}


def files(d):
    return sorted(Path(d).glob("*.png"), key=lambda p: p.name.lower()) if Path(d).is_dir() else []


def song_key(name):
    return " ".join(name.split()).lower()


def score_value(text):
    try:
        v = int(str(text).replace(",", "").strip())
    except ValueError:
        return 0
    return 10_000_000 + v if 0 < v < 100_000 else v


def first(*paths):
    return next((p for p in paths if p and Path(p).exists()), None)


def main():
    home = Path.home()
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--base", default=r"C:\arcaea", help="PC 프로그램 폴더 (templates, songs.json, 상수표.txt)")
    ap.add_argument("--table", help="상수표.txt (기본: base 또는 문서 폴더)")
    ap.add_argument("--input", help="입력표.txt (기본: base 또는 문서 폴더)")
    ap.add_argument("--save", help="저장표.txt (기본: 입력표 옆)")
    ap.add_argument("-o", "--output", default="score_reader_backup.json")
    a = ap.parse_args()
    base = Path(a.base)
    tpl = base / "templates"
    out = {"app": "score-reader-web", "version": 1, "exported": datetime.datetime.now().isoformat(timespec="seconds"),
           "glyphs": {}, "labels": {}, "colors": {}, "anchors": {}, "songs": {}, "table": "", "records": {}}
    for g in GROUPS:
        out["glyphs"][g] = [dict(ch=p.stem.split("_")[0], **pack(imread_gray(p))) for p in files(tpl / g)]
    for k in ("diff", "grade"):
        out["labels"][k] = [dict(label=p.stem.rsplit("_", 1)[0], **pack(imread_gray(p))) for p in files(tpl / k)]
    if (tpl / "diff_color.json").exists():
        out["colors"] = json.loads((tpl / "diff_color.json").read_text(encoding="utf-8"))
    # 기준 글자: templates\anchors\*.png (공개판) 또는 PC 프로그램 코드 안의 것(원본 arcaea_reader.py)
    for n in ("hs", "recall"):
        p = tpl / "anchors" / f"{n}.png"
        if p.exists():
            out["anchors"][n] = pack(imread_gray(p))
    if len(out["anchors"]) < 2 and (base / "arcaea_reader.py").exists():
        sys.path.insert(0, str(base))
        try:
            import arcaea_reader
            for n in ("hs", "recall"):
                out["anchors"].setdefault(n, pack(arcaea_reader.anchor(n)[2]))
        except Exception as e:
            print("기준 글자를 PC 프로그램에서 가져오지 못함:", e)
    if (base / "songs.json").exists():
        out["songs"] = json.loads((base / "songs.json").read_text(encoding="utf-8"))
    docs = [home / "OneDrive" / "문서", home / "Documents"]
    table = first(a.table, base / "상수표.txt", *[d / "상수표.txt" for d in docs])
    if table:
        out["table"] = Path(table).read_bytes().decode("utf-8-sig")
    inp = first(a.input, base / "입력표.txt", *[d / "입력표.txt" for d in docs])
    sav = first(a.save, Path(inp).with_name("저장표.txt") if inp else None)
    if inp and sav:
        il = Path(inp).read_bytes().decode("utf-8-sig").splitlines()
        sl = Path(sav).read_bytes().decode("utf-8-sig").splitlines()
        if len(il) == len(sl):
            for ln, sv in zip(il, sl):
                p = ln.split("\t")
                v = score_value(sv)
                if len(p) >= 2 and p[0].strip() and v > 0:
                    out["records"][f"{song_key(p[0])}|{p[1].strip()}"] = {"score": v, "song": p[0].strip(), "tag": p[1].strip()}
        else:
            print(f"입력표({len(il)}줄)와 저장표({len(sl)}줄) 줄 수가 달라 내 기록은 넣지 않음")
    Path(a.output).write_text(json.dumps(out, ensure_ascii=False), encoding="utf-8")
    n_g = sum(len(v) for v in out["glyphs"].values())
    print(f"완료: {Path(a.output).resolve()}")
    print(f"  글자 모양 {n_g}개, 난이도 {len(out['labels'].get('diff', []))}개, 등급 {len(out['labels'].get('grade', []))}개, "
          f"기준 글자 {len(out['anchors'])}개, 자켓 {len(out['songs'])}개, "
          f"상수표 {'있음' if out['table'] else '없음'}({table or '-'}), 내 기록 {len(out['records'])}곡")


if __name__ == "__main__":
    main()
